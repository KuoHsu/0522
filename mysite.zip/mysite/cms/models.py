from django.db import models
from datetime import *

# Create your models here.
class Student(models.Model):
	name = models.CharField(max_length=20)
	phone_number = models.CharField(max_length=15)
	address = models.CharField(max_length=50, blank=True)
	sex = models.BooleanField(default=True)
	age = models.DecimalField(max_digits=100, decimal_places=0,default = 20)

	def __str__(self):
		return self.name

class Introduce(models.Model):
	comment = models.CharField(max_length=50)
	student = models.ForeignKey(Student,on_delete=models.CASCADE)
	date = models.DateTimeField(default = datetime.now())


	def __str__(self):
		return self.student.name +': '+ self.comment
	def save(self, *args, **kwargs):
		date = datetime.now()
		super(self.__class__,self).save(*args,**kwargs)